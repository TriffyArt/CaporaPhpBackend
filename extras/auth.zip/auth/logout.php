<?php
    session_start();
    
    if(!isset($_GET['true']) && $_GET['logout'] === 'true') {
        $_SESSION = [];
        session_destroy();

        // Redirect to landing page
        header("Location: ./index.php");
        exit;
    } else {
        header("Location: dashboard.php");
        exit;
    }
?>